const ROAD = [50, 50];
const SAND = [40, 49];